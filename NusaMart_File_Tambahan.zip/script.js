// Fungsi tombol tambah produk
function tambahKeranjang(namaProduk) {
  const pesan = document.getElementById("pesan");
  if (pesan) {
    pesan.textContent = namaProduk + " berhasil ditambahkan (contoh).";
  } else {
    alert(namaProduk + " berhasil ditambahkan (contoh).");
  }
}
